# Image sources

- **Heart_attack-NIH.gif**: https://en.wikipedia.org/wiki/Coronary_arteries#/media/File:Heart_attack-NIH.gif

- **Latidos.gif**: https://en.wikipedia.org/wiki/File:Latidos.gif#/media/File:Latidos.gif

- **HeartImage__GordonJohnson__Pixabay.png**: https://pixabay.com/vectors/ekg-electrocardiogram-heart-art-2069872/